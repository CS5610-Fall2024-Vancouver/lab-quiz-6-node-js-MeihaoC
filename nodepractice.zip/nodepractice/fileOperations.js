const fs = require('fs');

function writeFilePromise(fileName, data) {
  return new Promise((resolve, reject) => {
    fs.writeFile(fileName, data, (err) => {
      if (err) {
        reject(err); 
      } else {
        resolve('File written successfully!');
      }
    });
  });
}

function readFilePromise(fileName) {
  return new Promise((resolve, reject) => {
    fs.readFile(fileName, 'utf-8', (err, data) => {
      if (err) {
        reject(err); 
      } else {
        resolve(data); 
      }
    });
  });
}

writeFilePromise('userData.txt', 'Hello, this is a test message!')
  .then((result) => {
    console.log('Success!');
    return readFilePromise('userData.txt');
  })
  .then((data) => {
    console.log('Data:', data); 
  })
  .catch((err) => {
    console.error('Error:', err);
  });
